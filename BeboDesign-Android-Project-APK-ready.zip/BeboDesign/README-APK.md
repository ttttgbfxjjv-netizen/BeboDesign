# Bebo Design — Android APK

هذا المشروع جاهز للبناء على GitHub Actions.

## استخراج APK
1. ارفع مجلد المشروع إلى مستودع GitHub جديد.
2. افتح تبويب Actions.
3. اختر Build Bebo Design APK.
4. شغّل Run workflow.
5. بعد انتهاء البناء افتح نتيجة التشغيل وحمّل artifact باسم BeboDesign-debug-apk.
6. فك الضغط وستجد `app-debug.apk`.

هذا APK تجريبي (Debug) للتثبيت والاختبار على هاتف Android.
