package com.bebodesign.portfolio

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.app.Activity

class MainActivity : Activity() {
    private val purple = Color.rgb(139,53,255); private val bg = Color.rgb(9,9,13)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun base(): LinearLayout { val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(20,24,20,16); l.setBackgroundColor(bg); return l }
    private fun tv(s:String, size:Float, bold:Boolean=false): TextView { val t=TextView(this); t.text=s; t.textSize=size; t.setTextColor(Color.WHITE); if(bold)t.setTypeface(null,1); t.setPadding(4,8,4,8); return t }
    private fun btn(s:String, click:()->Unit): Button { val b=Button(this); b.text=s; b.setTextColor(Color.WHITE); b.setOnClickListener{click()}; b.background=GradientDrawable().apply{setColor(purple);cornerRadius=28f}; return b }
    private fun showHome(){ val l=base(); l.addView(tv("Bebo Design",30f,true)); l.addView(tv("تصميم يعكس هويتك",18f)); l.addView(tv("\nأهلًا 👋\nأنا بيو ديزاينر\nمصمم جرافيك وصاحب شغف بتحويل الأفكار إلى هوية بصرية مميزة.",20f)); l.addView(btn("شوف شغلي",::showWorks), lp()); l.addView(tv("\nأحدث الأعمال",20f,true)); listOf("Coffeeto — هوية بصرية","FITZONE — لوجو","TRAVELIA — تصميم سياحي").forEach{l.addView(tv("•  $it",17f))}; l.addView(btn("عنّي",::showAbout),lp()); l.addView(btn("تواصل معي",::showContact),lp()); setContentView(l) }
    private fun showWorks(){ val l=base(); l.addView(tv("أعمالي",28f,true)); listOf("كل","تصميمات","لوجوهات","فيديوهات").forEach{l.addView(tv("  $it",16f))}; listOf("Coffeeto — هوية بصرية","FITZONE — لوجو رياضي","TRAVELIA — هوية سياحية","Digital Agency — تصميم ويب","SPARK — هوية تجارية").forEach{ val b=btn(it){showDetails(it)}; l.addView(b,lp()) }; l.addView(btn("رجوع",::showHome),lp()); setContentView(l) }
    private fun showDetails(name:String){ val l=base(); l.addView(tv("تفاصيل العمل",27f,true)); l.addView(tv(name,22f,true)); l.addView(tv("\nمشروع تصميم احترافي ضمن معرض Bebo Design.\n\nيمكن هنا إضافة صور العمل، وصف المشروع، الأدوات المستخدمة، وتاريخ التنفيذ.",17f)); l.addView(btn("رجوع للأعمال",::showWorks),lp()); setContentView(l) }
    private fun showAbout(){ val l=base(); l.addView(tv("عنّي",28f,true)); l.addView(tv("أنا Bebo Design",23f,true)); l.addView(tv("\nمصمم جرافيك أعمل على تصميم الهويات البصرية واللوجوهات والمحتوى الإبداعي.\n\nالمهارات\nPhotoshop • Illustrator • After Effects",17f)); l.addView(btn("رجوع",::showHome),lp()); setContentView(l) }
    private fun showContact(){ val l=base(); l.addView(tv("تواصل معي",28f,true)); l.addView(tv("\nلأي مشروع أو استفسار، يمكنك التواصل معي عبر المنصات التالية:",17f)); l.addView(btn("واتساب",{}),lp()); l.addView(btn("Instagram",{}),lp()); l.addView(btn("Facebook",{}),lp()); l.addView(btn("البريد الإلكتروني",{}),lp()); l.addView(btn("رجوع",::showHome),lp()); setContentView(l) }
    private fun lp(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,64).apply{setMargins(0,8,0,8)}
}
