plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.bebodesign.portfolio"; compileSdk = 36
    defaultConfig { applicationId = "com.bebodesign.portfolio"; minSdk = 23; targetSdk = 36; versionCode = 1; versionName = "1.0" }
}
